package com.wisnuwahyudi.themealapp.network

import com.wisnuwahyudi.themealapp.model.ResponseDetailMeal
import com.wisnuwahyudi.themealapp.model.ResponseListMeal
import io.reactivex.rxjava3.core.Flowable
import retrofit2.http.GET
import retrofit2.http.Query

interface IService {

    @GET("api/json/v1/1/filter.php?c=Seafood") //Endpoint
    fun getListMeal() : Flowable<ResponseListMeal>


    @GET("api/json/v1/1/lookup.php?") //Endpoint
    fun getDetailMeal(
        @Query("i") IdMeal : String
    ) : Flowable<ResponseDetailMeal>

}