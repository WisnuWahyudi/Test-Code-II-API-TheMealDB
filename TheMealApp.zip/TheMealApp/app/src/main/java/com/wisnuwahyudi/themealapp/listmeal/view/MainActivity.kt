package com.wisnuwahyudi.themealapp.listmeal.view

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import com.wisnuwahyudi.themealapp.databinding.ActivityMainBinding
import com.wisnuwahyudi.themealapp.listmeal.adapter.ListMealsAdapter
import com.wisnuwahyudi.themealapp.listmeal.presenter.IMealView
import com.wisnuwahyudi.themealapp.listmeal.presenter.MealPresenter
import com.wisnuwahyudi.themealapp.model.MealsItem

class MainActivity : AppCompatActivity(), IMealView {

    private lateinit var binding: ActivityMainBinding
    private lateinit var Listpresenter: MealPresenter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        Listpresenter = MealPresenter(this)
        binding.progressBar.visibility = View.VISIBLE
        Listpresenter.getListMeal()

    }

    override fun listItemMeals(item: List<MealsItem?>?) {
        val adapterMeals = ListMealsAdapter(item)

        with(binding.rvListMeal){
            layoutManager = GridLayoutManager(context, 2)
            setHasFixedSize(true)
            adapter = adapterMeals
        }
        binding.progressBar.visibility = View.GONE
    }

    override fun listError(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }

}