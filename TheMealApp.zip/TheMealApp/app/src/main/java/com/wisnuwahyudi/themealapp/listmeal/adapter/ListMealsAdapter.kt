package com.wisnuwahyudi.themealapp.listmeal.adapter

import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.wisnuwahyudi.themealapp.databinding.ListMealBinding
import com.wisnuwahyudi.themealapp.detailmeals.view.DetailMealsActivity
import com.wisnuwahyudi.themealapp.model.MealsItem

class ListMealsAdapter(val dataAll : List<MealsItem?>?) : RecyclerView.Adapter<ListMealsAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = ListMealBinding.inflate(LayoutInflater.from(parent.context),parent,false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val mealsItem = dataAll?.get(position)
        holder.bindData(mealsItem)
    }

    override fun getItemCount(): Int  {
        return dataAll?.size ?: 0
    }

    class ViewHolder(val binding : ListMealBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bindData(meals : MealsItem?){
            with(binding){
                Glide.with(itemView.context)
                    .load(meals?.strMealThumb)
                    .into(imgPicMeal)

                txtNameMeal.text = meals?.strMeal.toString()

                itemView.setOnClickListener {
                    val intent = Intent(itemView.context, DetailMealsActivity::class.java)
                    intent.putExtra(DetailMealsActivity.keyId,meals?.idMeal)
                    itemView.context.startActivity(intent)
                }
            }
        }
    }
}