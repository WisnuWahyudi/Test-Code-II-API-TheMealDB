package com.wisnuwahyudi.themealapp.detailmeals.viewmodel

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.wisnuwahyudi.themealapp.model.MealsItemFullDetail
import com.wisnuwahyudi.themealapp.network.ConfigNetwork
import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers
import io.reactivex.rxjava3.schedulers.Schedulers

class DetailMealViewModel : ViewModel() {

            private  var dataDetailMutable = MutableLiveData<List<MealsItemFullDetail?>?>()

      fun setMealDetail(idMeal : String){

          ConfigNetwork.getApiService().getDetailMeal(idMeal).subscribeOn(Schedulers.io())
              .observeOn(AndroidSchedulers.mainThread())
              .subscribe({
                  val data : List<MealsItemFullDetail?>? = it.meals

                  dataDetailMutable.postValue(data)

              },{
                    Log.e(DetailMealViewModel::class.java.simpleName,"ERROR")
              })
      }

   fun getDetailMeals() : LiveData<List<MealsItemFullDetail?>?> {
        return dataDetailMutable
   }
}