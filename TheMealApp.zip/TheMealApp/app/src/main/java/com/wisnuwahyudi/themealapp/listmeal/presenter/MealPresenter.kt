package com.wisnuwahyudi.themealapp.listmeal.presenter

import com.wisnuwahyudi.themealapp.network.ConfigNetwork
import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers
import io.reactivex.rxjava3.schedulers.Schedulers

class MealPresenter(val viewListMeal: IMealView) {
    fun getListMeal() {
        ConfigNetwork.getApiService().getListMeal().subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe({

                    viewListMeal.listItemMeals(it.mealsList)
            },{
                viewListMeal.listError("Page is Empty || Error...")
            })
    }
}