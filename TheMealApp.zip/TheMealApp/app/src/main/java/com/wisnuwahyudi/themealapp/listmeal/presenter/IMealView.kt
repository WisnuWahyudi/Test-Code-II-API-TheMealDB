package com.wisnuwahyudi.themealapp.listmeal.presenter

import com.wisnuwahyudi.themealapp.model.MealsItem

interface IMealView {
    fun listItemMeals(item : List<MealsItem?>?)
    fun listError(msg : String)
}