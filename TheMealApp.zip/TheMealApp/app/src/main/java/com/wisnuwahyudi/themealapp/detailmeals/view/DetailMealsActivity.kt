
package com.wisnuwahyudi.themealapp.detailmeals.view

import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import com.wisnuwahyudi.themealapp.databinding.ActivityDetailmealsBinding
import com.wisnuwahyudi.themealapp.detailmeals.viewmodel.DetailMealViewModel
import com.wisnuwahyudi.themealapp.model.MealsItemFullDetail


class DetailMealsActivity : AppCompatActivity() {

    companion object {
        const val keyId = "keysIdMeals"
    }

    private lateinit var binding: ActivityDetailmealsBinding
    private lateinit var detailMealViewModel: DetailMealViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailmealsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val accId = intent.getStringExtra(keyId)

        detailMealViewModel = ViewModelProvider(
            this,
            ViewModelProvider.NewInstanceFactory()
        ).get(DetailMealViewModel::class.java)

        if (accId != null) {
            detailMealViewModel.setMealDetail(accId)
        }

        binding.progressBar.visibility = View.VISIBLE

        detailMealViewModel.getDetailMeals().observe(this, Observer {
            it?.forEach {
                showDetail(it)
            }
        })

    }

    fun showDetail(item: MealsItemFullDetail?) {
        binding.txtNameMeal.text = item?.strMeal.toString()
        binding.txtCategory.text = item?.strCategory.toString()

        Glide.with(this)
            .load(item?.strMealThumb)
            .into(binding.imgMealDetail)
        binding.progressBar.visibility = View.GONE

        val cResep = arrayOf(
            item?.strIngredient1.toString(),
            item?.strIngredient2.toString(),
            item?.strIngredient3.toString(),
            item?.strIngredient4.toString(),
            item?.strIngredient5.toString(),
            item?.strIngredient6.toString(),
            item?.strIngredient7.toString(),
            item?.strIngredient8.toString(),
            item?.strIngredient9.toString(),
            item?.strIngredient10.toString()
        )

        val adapter = ArrayAdapter<String>(
            this,
            android.R.layout.simple_list_item_1, android.R.id.text1, cResep
        )
        binding.rvResep.adapter = adapter

        binding.txtDescription.text = item?.strInstructions
    }
}
